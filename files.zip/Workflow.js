const mongoose = require('mongoose');

const auditEntrySchema = new mongoose.Schema({
  action: { type: String, enum: ['CREATE', 'TRANSFER', 'ESCALATE', 'NOTE', 'CANCEL', 'COMPLETE'], required: true },
  fromDept: String,
  toDept: String,
  actor: String,
  actorId: String,
  note: String,
  timestamp: { type: Date, default: Date.now },
  hash: String,
  prevHash: String
}, { _id: false });

const workflowSchema = new mongoose.Schema({
  workflowId: { type: String, unique: true },
  patientName: { type: String, required: true },
  patientAge: Number,
  chiefComplaint: { type: String, required: true },
  template: {
    type: String,
    enum: ['emergency_trauma', 'diagnostic_workup', 'elective_surgery', 'medication_review', 'fast_track'],
    required: true
  },
  priority: { type: String, enum: ['critical', 'high', 'medium', 'low'], default: 'medium' },
  status: { type: String, enum: ['active', 'completed', 'cancelled', 'on_hold'], default: 'active' },
  currentDepartment: { type: String, required: true },
  departmentPath: [String],
  currentStep: { type: Number, default: 0 },
  assignedTo: String,
  assignedToId: String,
  createdBy: String,
  createdById: String,
  slaDeadline: Date,
  slaBreach: { type: Boolean, default: false },
  escalated: { type: Boolean, default: false },
  escalationReason: String,
  auditTrail: [auditEntrySchema],
  notes: [{ text: String, author: String, timestamp: { type: Date, default: Date.now } }],
  completedAt: Date,
  totalDurationMinutes: Number
}, {
  timestamps: true
});

// Auto-generate workflowId before save
workflowSchema.pre('save', async function (next) {
  if (!this.workflowId) {
    const count = await mongoose.model('Workflow').countDocuments();
    const year = new Date().getFullYear();
    this.workflowId = `WF-${year}-${String(count + 1).padStart(4, '0')}`;
  }
  next();
});

// Set SLA deadline based on priority
workflowSchema.pre('save', function (next) {
  if (this.isNew) {
    const slaMinutes = { critical: 15, high: 60, medium: 240, low: 480 };
    const minutes = slaMinutes[this.priority] || 240;
    this.slaDeadline = new Date(Date.now() + minutes * 60 * 1000);
  }
  next();
});

module.exports = mongoose.model('Workflow', workflowSchema);
