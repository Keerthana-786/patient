const router = require('express').Router();
const Workflow = require('../models/Workflow');
const { createAuditEntry } = require('../services/auditService');
const { getTemplateConfig } = require('../services/workflowService');

// GET /api/workflows — list all (optionally filtered)
router.get('/', async (req, res, next) => {
  try {
    const { status, priority, department } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (priority) filter.priority = priority;
    if (department) filter.currentDepartment = department;

    const workflows = await Workflow.find(filter).sort({ createdAt: -1 }).limit(200);
    res.json(workflows);
  } catch (err) { next(err); }
});

// GET /api/workflows/:id
router.get('/:id', async (req, res, next) => {
  try {
    const wf = await Workflow.findOne({ workflowId: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });
    res.json(wf);
  } catch (err) { next(err); }
});

// POST /api/workflows — create new
router.post('/', async (req, res, next) => {
  try {
    const { patientName, patientAge, chiefComplaint, template, priority } = req.body;
    if (!patientName || !chiefComplaint || !template) {
      return res.status(400).json({ error: 'patientName, chiefComplaint, and template are required' });
    }

    const config = getTemplateConfig(template);
    const wf = new Workflow({
      patientName,
      patientAge,
      chiefComplaint,
      template,
      priority: priority || 'medium',
      currentDepartment: config.path[0],
      departmentPath: config.path,
      currentStep: 0,
      createdBy: req.user.name || 'System',
      createdById: req.user.userId
    });

    const firstAudit = createAuditEntry({
      action: 'CREATE',
      toDept: config.path[0],
      actor: req.user.name || 'System',
      actorId: req.user.userId,
      note: `Workflow created: ${config.name}`,
      prevHash: '0'
    });
    wf.auditTrail.push(firstAudit);

    await wf.save();

    // Emit real-time update
    req.app.get('io').emit('workflow:created', wf);
    res.status(201).json(wf);
  } catch (err) { next(err); }
});

// PUT /api/workflows/:id/transfer — advance to next department
router.put('/:id/transfer', async (req, res, next) => {
  try {
    const { note } = req.body;
    const wf = await Workflow.findOne({ workflowId: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });
    if (wf.status !== 'active') return res.status(400).json({ error: 'Workflow is not active' });

    const prevDept = wf.currentDepartment;
    const nextStep = wf.currentStep + 1;

    if (nextStep >= wf.departmentPath.length) {
      // Complete the workflow
      wf.status = 'completed';
      wf.completedAt = new Date();
      wf.totalDurationMinutes = Math.round((wf.completedAt - wf.createdAt) / 60000);
    } else {
      wf.currentStep = nextStep;
      wf.currentDepartment = wf.departmentPath[nextStep];
    }

    const prevAudit = wf.auditTrail[wf.auditTrail.length - 1];
    const audit = createAuditEntry({
      action: wf.status === 'completed' ? 'COMPLETE' : 'TRANSFER',
      fromDept: prevDept,
      toDept: wf.currentDepartment,
      actor: req.user.name || 'System',
      actorId: req.user.userId,
      note: note || '',
      prevHash: prevAudit?.hash || '0'
    });
    wf.auditTrail.push(audit);

    await wf.save();
    req.app.get('io').emit('workflow:updated', wf);
    res.json(wf);
  } catch (err) { next(err); }
});

// PUT /api/workflows/:id/escalate
router.put('/:id/escalate', async (req, res, next) => {
  try {
    const { reason } = req.body;
    const wf = await Workflow.findOne({ workflowId: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });

    wf.escalated = true;
    wf.escalationReason = reason || 'Manually escalated';
    wf.priority = 'critical';
    const slaMs = 15 * 60 * 1000;
    wf.slaDeadline = new Date(Date.now() + slaMs);

    const prevAudit = wf.auditTrail[wf.auditTrail.length - 1];
    const audit = createAuditEntry({
      action: 'ESCALATE',
      fromDept: wf.currentDepartment,
      toDept: wf.currentDepartment,
      actor: req.user.name || 'System',
      actorId: req.user.userId,
      note: reason || 'Escalated to critical',
      prevHash: prevAudit?.hash || '0'
    });
    wf.auditTrail.push(audit);

    await wf.save();
    req.app.get('io').emit('workflow:escalated', wf);
    res.json(wf);
  } catch (err) { next(err); }
});

// POST /api/workflows/:id/notes
router.post('/:id/notes', async (req, res, next) => {
  try {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'Note text required' });

    const wf = await Workflow.findOne({ workflowId: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });

    wf.notes.push({ text, author: req.user.name || 'System' });

    const prevAudit = wf.auditTrail[wf.auditTrail.length - 1];
    const audit = createAuditEntry({
      action: 'NOTE',
      fromDept: wf.currentDepartment,
      toDept: wf.currentDepartment,
      actor: req.user.name || 'System',
      actorId: req.user.userId,
      note: text,
      prevHash: prevAudit?.hash || '0'
    });
    wf.auditTrail.push(audit);

    await wf.save();
    req.app.get('io').emit('workflow:updated', wf);
    res.json(wf);
  } catch (err) { next(err); }
});

// PUT /api/workflows/:id/cancel
router.put('/:id/cancel', async (req, res, next) => {
  try {
    const wf = await Workflow.findOne({ workflowId: req.params.id });
    if (!wf) return res.status(404).json({ error: 'Workflow not found' });
    wf.status = 'cancelled';

    const prevAudit = wf.auditTrail[wf.auditTrail.length - 1];
    wf.auditTrail.push(createAuditEntry({
      action: 'CANCEL',
      fromDept: wf.currentDepartment,
      actor: req.user.name || 'System',
      actorId: req.user.userId,
      prevHash: prevAudit?.hash || '0'
    }));

    await wf.save();
    req.app.get('io').emit('workflow:updated', wf);
    res.json(wf);
  } catch (err) { next(err); }
});

module.exports = router;
