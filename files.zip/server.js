require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const mongoose = require('mongoose');
const cron = require('node-cron');

const authRoutes = require('./routes/auth');
const workflowRoutes = require('./routes/workflows');
const departmentRoutes = require('./routes/departments');
const analyticsRoutes = require('./routes/analytics');
const aiRoutes = require('./routes/ai');
const { verifyToken } = require('./middleware/auth');
const { checkSLABreaches } = require('./utils/slaChecker');
const logger = require('./utils/logger');

const app = express();
const server = http.createServer(app);

// Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST']
  }
});

// Make io accessible in routes
app.set('io', io);

// Middleware
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }));
app.use(express.json());

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), version: '2.0.0' });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/workflows', verifyToken, workflowRoutes);
app.use('/api/departments', verifyToken, departmentRoutes);
app.use('/api/analytics', verifyToken, analyticsRoutes);
app.use('/api/ai', verifyToken, aiRoutes);

// Socket.IO connection handling
io.on('connection', (socket) => {
  logger.info(`Client connected: ${socket.id}`);
  socket.on('join-department', (deptId) => {
    socket.join(`dept:${deptId}`);
  });
  socket.on('join-workflow', (workflowId) => {
    socket.join(`workflow:${workflowId}`);
  });
  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
});

// SLA breach checker — runs every minute
cron.schedule('* * * * *', async () => {
  try {
    const breaches = await checkSLABreaches();
    if (breaches.length > 0) {
      io.emit('sla-breaches', breaches);
      logger.warn(`SLA breaches detected: ${breaches.length}`);
    }
  } catch (err) {
    logger.error('SLA check failed:', err);
  }
});

// Global error handler
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// DB + Server Start
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/idwas';

mongoose.connect(MONGODB_URI)
  .then(() => {
    logger.info('MongoDB connected');
    server.listen(PORT, () => {
      logger.info(`IDWAS Backend running on port ${PORT}`);
    });
  })
  .catch((err) => {
    logger.error('MongoDB connection failed:', err);
    process.exit(1);
  });

module.exports = { app, io };
