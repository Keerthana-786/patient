const router = require('express').Router();
const Workflow = require('../models/Workflow');

// POST /api/ai/query — natural language question
router.post('/query', async (req, res, next) => {
  try {
    const { question } = req.body;
    if (!question) return res.status(400).json({ error: 'question required' });

    // Gather live context
    const [activeWorkflows, deptLoads] = await Promise.all([
      Workflow.find({ status: 'active' }).select('workflowId patientName priority currentDepartment createdAt slaDeadline escalated').limit(50),
      Workflow.aggregate([
        { $match: { status: 'active' } },
        { $group: { _id: '$currentDepartment', count: { $sum: 1 } } }
      ])
    ]);

    const context = {
      activeWorkflows: activeWorkflows.map(w => ({
        id: w.workflowId, patient: w.patientName, priority: w.priority,
        dept: w.currentDepartment, waitMinutes: Math.round((Date.now() - w.createdAt) / 60000),
        slaBreached: w.slaDeadline < new Date(), escalated: w.escalated
      })),
      departmentLoads: deptLoads.reduce((acc, d) => { acc[d._id] = d.count; return acc; }, {})
    };

    // Call Anthropic API
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 600,
        system: `You are a hospital workflow optimization AI for QuantumShield IDWAS. 
You have real-time access to hospital department loads and active patient workflows.
Respond in JSON: { "answer": "...", "recommendation": "...", "urgency": "low|medium|high" }
Be concise, clinical, and actionable. Patient safety is always priority 1.`,
        messages: [{
          role: 'user',
          content: `Context: ${JSON.stringify(context)}\n\nQuestion: ${question}`
        }]
      })
    });

    const data = await response.json();
    const text = data.content?.map(c => c.text || '').join('') || '{}';

    let parsed;
    try {
      parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
    } catch {
      parsed = { answer: text, recommendation: '', urgency: 'low' };
    }

    res.json(parsed);
  } catch (err) { next(err); }
});

// POST /api/ai/predict — workload prediction
router.post('/predict', async (req, res, next) => {
  try {
    const { timeHorizonHours = 2 } = req.body;

    const [deptLoads, recentRate] = await Promise.all([
      Workflow.aggregate([
        { $match: { status: 'active' } },
        { $group: { _id: '$currentDepartment', count: { $sum: 1 } } }
      ]),
      Workflow.aggregate([
        { $match: { createdAt: { $gte: new Date(Date.now() - 3 * 60 * 60 * 1000) } } },
        { $group: { _id: null, count: { $sum: 1 } } }
      ])
    ]);

    const CAPACITY = { er: 10, triage: 8, lab: 15, radiology: 8, icu: 6, surgery: 4, pharmacy: 20, discharge: 30 };
    const loadsMap = deptLoads.reduce((acc, d) => { acc[d._id] = d.count; return acc; }, {});
    const avgHourlyRate = Math.round((recentRate[0]?.count || 0) / 3);

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 500,
        system: `You are a hospital AI predicting future department overloads.
Respond ONLY in JSON: { "predictions": [{ "department": string, "currentLoad": number, "predictedLoad": number, "riskLevel": "low|medium|high|critical", "recommendation": string }], "summary": string }`,
        messages: [{
          role: 'user',
          content: `Current loads: ${JSON.stringify(loadsMap)}
Capacities: ${JSON.stringify(CAPACITY)}
Avg hourly intake: ${avgHourlyRate} new workflows/hour
Predict loads in ${timeHorizonHours} hours.`
        }]
      })
    });

    const data = await response.json();
    const text = data.content?.map(c => c.text || '').join('') || '{}';
    let parsed;
    try {
      parsed = JSON.parse(text.replace(/```json|```/g, '').trim());
    } catch {
      parsed = { predictions: [], summary: 'Prediction unavailable' };
    }

    res.json({ ...parsed, generatedAt: new Date().toISOString(), timeHorizonHours });
  } catch (err) { next(err); }
});

// GET /api/ai/recommendations — proactive suggestions
router.get('/recommendations', async (req, res, next) => {
  try {
    const slaBreaching = await Workflow.find({
      status: 'active',
      slaDeadline: { $lt: new Date(Date.now() + 15 * 60 * 1000) }
    }).select('workflowId patientName priority currentDepartment slaDeadline').limit(10);

    const recommendations = slaBreaching.map(w => ({
      type: 'sla_warning',
      workflowId: w.workflowId,
      patient: w.patientName,
      department: w.currentDepartment,
      message: `${w.patientName} SLA expires in ${Math.round((w.slaDeadline - Date.now()) / 60000)} minutes`,
      priority: w.priority
    }));

    res.json(recommendations);
  } catch (err) { next(err); }
});

module.exports = router;
