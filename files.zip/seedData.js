require('dotenv').config({ path: '../.env' });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Workflow = require('../src/models/Workflow');
const { User } = require('../src/models/User');
const { createAuditEntry } = require('../src/services/auditService');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/idwas';

async function seed() {
  await mongoose.connect(MONGODB_URI);
  console.log('Connected to MongoDB');

  // Clear existing
  await Promise.all([User.deleteMany(), Workflow.deleteMany()]);
  console.log('Cleared existing data');

  // Seed users
  const hash = async (p) => bcrypt.hash(p, 12);
  const users = await User.insertMany([
    { name: 'Admin User', email: 'admin@qs.com', passwordHash: await hash('Admin@123'), role: 'admin', permissions: ['view_workflow','create_workflow','transfer','escalate','cancel','add_note','view_analytics','manage_users'] },
    { name: 'Dr. Sarah Chen', email: 'doctor@qs.com', passwordHash: await hash('Doctor@123'), role: 'doctor', department: 'er', permissions: ['view_workflow','create_workflow','transfer','escalate','add_note'] },
    { name: 'Nurse Maria Santos', email: 'nurse@qs.com', passwordHash: await hash('Nurse@123'), role: 'nurse', department: 'triage', permissions: ['view_workflow','transfer','add_note'] }
  ]);
  console.log(`Seeded ${users.length} users`);

  // Seed workflows
  const workflows = [
    { patientName: 'James Carter', patientAge: 45, chiefComplaint: 'Chest pain, shortness of breath', template: 'emergency_trauma', priority: 'critical', currentDepartment: 'radiology', currentStep: 3, departmentPath: ['er','triage','lab','radiology','icu','surgery','pharmacy','discharge'], escalated: true, escalationReason: 'Suspected STEMI' },
    { patientName: 'Sofia Mendes', patientAge: 32, chiefComplaint: 'High fever, severe headache', template: 'diagnostic_workup', priority: 'high', currentDepartment: 'lab', currentStep: 1, departmentPath: ['triage','lab','radiology','pharmacy','discharge'] },
    { patientName: 'Ravi Patel', patientAge: 58, chiefComplaint: 'Knee replacement pre-op', template: 'elective_surgery', priority: 'medium', currentDepartment: 'lab', currentStep: 1, departmentPath: ['triage','lab','surgery','pharmacy','discharge'] },
    { patientName: 'Emma Walsh', patientAge: 28, chiefComplaint: 'Prescription renewal', template: 'medication_review', priority: 'low', currentDepartment: 'triage', currentStep: 0, departmentPath: ['triage','pharmacy','discharge'] }
  ];

  for (const wfData of workflows) {
    const wf = new Workflow({ ...wfData, createdBy: 'Seed Script', createdById: users[0]._id.toString() });
    const firstAudit = createAuditEntry({ action: 'CREATE', toDept: wfData.departmentPath[0], actor: 'Seed Script', actorId: users[0]._id.toString(), note: 'Demo workflow', prevHash: '0' });
    wf.auditTrail.push(firstAudit);
    await wf.save();
  }

  // One completed workflow
  const completedWf = new Workflow({
    patientName: 'Liam Chen', patientAge: 34, chiefComplaint: 'Appendectomy post-op follow-up',
    template: 'diagnostic_workup', priority: 'medium', status: 'completed',
    currentDepartment: 'discharge', currentStep: 4,
    departmentPath: ['triage','lab','radiology','pharmacy','discharge'],
    completedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    totalDurationMinutes: 127,
    createdBy: 'Seed Script', createdById: users[0]._id.toString()
  });
  const audit = createAuditEntry({ action: 'CREATE', toDept: 'triage', actor: 'Seed Script', actorId: users[0]._id.toString(), prevHash: '0' });
  completedWf.auditTrail.push(audit);
  await completedWf.save();

  console.log('Seeded 5 workflows');
  console.log('\n✅ Seed complete! Login credentials:');
  console.log('  Admin:  admin@qs.com  / Admin@123');
  console.log('  Doctor: doctor@qs.com / Doctor@123');
  console.log('  Nurse:  nurse@qs.com  / Nurse@123');

  await mongoose.disconnect();
}

seed().catch(err => { console.error(err); process.exit(1); });
